<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
<head>	
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="generator" content="Jizzomaru CMS 1.0" />
<!-- leave this for stats -->
<title>WIN COMPUTER - Toko Komputer Online Murah Surabaya</title>
<link rel="shortcut icon" href="/images/Logo.png" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="s3Slider.css" type="text/css" media="screen" />
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/s3Slider.js" type="text/javascript"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-6068671-6']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script>
$(document).ready(function() { 
   $('#s3slider').s3Slider({ 
      timeOut: 4000 
   });
});
</script>
<style>
.tdkanan { text-align: right; padding: 0px 3px;}
.tdtengah { text-align: center; }

table {
 font-size: 95%;
 font-family: 'Lucida Grande', Helvetica, verdana, sans-serif;
 background-color:#fff;
 border-collapse: collapse;
 width: 100%;
 line-height: 1.2em;
}
caption {
 font-size: 30px;
 font-weight: bold;
 color: #002084;
 text-align: left;
 padding: 10px 0px;
 margin-bottom: 2px;
 text-transform: capitalize;
}
thead th {
 border-right: 2px solid #fff;
 font-size: 13px;
 color:#fff;
 text-align:center;
 padding:2px;
 height:20px;
 background-color: #004080;
}
tfoot {
 color:#002084;
 padding:2px;
 text-transform:uppercase;
 font-size:1.2em;
 font-weigth: bold;
 margin-top:6px;
 border-top: 6px solid #004080;
 border-bottom: 6px solid #004080;
}
tbody tr {
 background-color:#fff;
}
tbody td {
 color:#002084;
 font-size: 12px;
 padding:5px;
 text-align:left;
 border-bottom: 1px solid #004080;
}
tbody th {
 text-align:left;
 padding: 2px;
}
tbody td a, tbody th a {
 color:#002084;
 text-decoration:none;
 font-weight:normal;
}
tbody td a:hover, tbody th a:hover {
 text-decoration:none;
}
tbody .batesatas {
 border-top: 3px solid #004080;
}
</style>
</head>
<body>
<div id="container">
	<div id="logo">
		<a href="index.php" class="logo">home</a>
		<p class="site-desc"><b>supplier.hardware.software</b></p>
	</div>	
	<div id="logoside">	
	  <div id="list-page-nav">		
		<ul id="list-nav">			
			<li><a href="about.php">ABOUT</a></li>			
			<li> | </li>			
			<li><a href="howto.php">HOW-TO</a></li>			
			<li> | </li>			
			<li><a href="simulasi.php">SIMULASI</a></li>			
			<li> | </li>			
			<li><a href="konfirmasi.php">KONFIRMASI TRANSFER</a></li>			
			<li> | </li>			
			<li><a href="http://www.jne.co.id/index.php?mib=tariff&lang=IN" target="_blank">TARIF JNE</a></li>			
		</ul>		
		<div id="iklan-header"></div>		
		<div id="alamat">ITC Mega Grosir Lt 2 Blok K3A no 3 Surabaya | CALL: 031-37301771 | WA: 085731000839 | EMAIL: win_komputer@yahoo.com</div>	
	  </div>	
	</div>	
	<div id="logounder">	
	  <div id="list-page-nav">		
		<ul id="list-nav">			
		<li><a href='price-list.php?q=cpu' >Processor</a></li><li><a href='price-list.php?q=mbo' >Motherboard</a></li><li><a href='price-list.php?q=hdd' >Harddisk</a></li><li><a href='price-list.php?q=ssd' >SSD</a></li><li><a href='price-list.php?q=ram' >Memory RAM</a></li><li><a href='price-list.php?q=vga' >VGA</a></li><li><a href='price-list.php?q=psu' >Power Supply</a></li><li><a href='price-list.php?q=cas' >Casing</a></li><li><a href='price-list.php?q=mon' >LED Monitor</a></li><li><a href='price-list.php?q=opd' >Optical Drive</a></li><li><a href='price-list.php?q=knm' >Keyboard Mouse</a></li><li><a href='price-list.php?q=gcc' >Gaming Chair</a></li><li><a href='price-list.php?q=cnf' >Cooler & Fan</a></li><li><a href='price-list.php?q=sno' >Software & OS</a></li><li><a href='price-list.php?q=nco' >Notebook Cooler</a></li><li><a href='price-list.php?q=fdd' >Flashdisk</a></li><li><a href='price-list.php?q=mmc' >Memory Card</a></li><li><a href='price-list.php?q=uns' >UPS & Stavolt</a></li><li><a href='price-list.php?q=nwk' >Networking</a></li><li><a href='price-list.php?q=spk' >Speaker</a></li><li><a href='price-list.php?q=hst' >Headset</a></li><li><a href='price-list.php?q=snc' >Sound Card</a></li><li><a href='price-list.php?q=prt' >Printer & Scanner</a></li><li><a href='price-list.php?q=crg' >Cartidge & Toner</a></li><li><a href='price-list.php?q=ddt' >Digital Drawing Tablet</a></li><li><a href='price-list.php?q=aio' >Intel NUC & PC Branded</a></li><li><a href='price-list.php?q=pro' >Projector</a></li>		
		</ul>	
	  </div>	
	</div>	
	<div id="body"><br />
<b>Warning</b>:  date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'Asia/Krasnoyarsk' for 'WIB/7.0/no DST' instead in <b>/home/winkomp1/public_html/konfirmasi.php</b> on line <b>20</b><br />
<br />
<b>Warning</b>:  date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'Asia/Krasnoyarsk' for 'WIB/7.0/no DST' instead in <b>/home/winkomp1/public_html/konfirmasi.php</b> on line <b>20</b><br />
<br><br>
	<div id="sidebar">
		<div id="sidebar1">
		 <div class="title">Kontak Kami</div>
		 <div class="isi">
<h3>WIN KOMPUTER</h3>
<p>Hi-Tech Mall<br>Lt Dasar Blok A no:42<br>Surabaya</p>
<br>
                   <img src="images/icon-phone.png" alt="Call us" title="Call us" />&nbsp;<span style="margin-top:10px;position:absolute;">(031)-5470970</span></br>
                   <img src="images/icon-sms.png" alt="Text us" title="Text us" />&nbsp;<span style="margin-top:10px;position:absolute;">085731000839 (WA)</span></br>
                   <img src="images/icon-bbm.png" alt="BBM us" title="BBM us" />&nbsp;<span style="margin-top:10px;position:absolute;">D0C327D8</span></br>
                   <img src="images/icon-email.png" alt="Email us" title="Email us" />&nbsp;<span style="margin-top:10px;position:absolute;">win_komputer@yahoo.com</span></br></br>
<div class="tengah tebel-normal">
<hr>
</br>
JAM OPERASIONAL</br>
SENIN - JUMAT : 10.30 - 17.00</br>
SABTU : 10.30 - 16.00</br>
HARI MINGGU ATAU HARI BESAR TUTUP</br>
</div>
                 </div>
		</div>
                <div id="clear"></div>
		<div id="sidebar2">
		 <div class="title">HowTo Order</div>
		 <div class="isi">
		 <ul>
<li>Pilih barang yang ada dalam website kami.</li>
<li>Cek Ongkos Kirim ke Kota Anda , Ongkos kirim dapat dilihat di Link Tarif dan harga yang tertera dihitung per kg.</li>
<li>Tambahkan harga barang yang di website + ongkos kirim dari JNE dikalikan berat barang yang ingin dikirim.</li>
</ul></div>
		</div>
		<div id="clear"></div>
		<div id="sidebar3">
		 <div class="title">Payment Transfer</div>
		 <div class="isi"><div id='bca'></div></div>
		</div>
		<div id="clear"></div>
		<div id="sidebar4">
		 <div class="title">Menu Navigasi</div>
		 <div class="isi"><ul>
			<li><a href="http://www.winkomputer.com/about.php">ABOUT</a></li>
			<li><a href="http://www.winkomputer.com/howto.php">HOW-TO</a></li>
			<li><a href="http://www.winkomputer.com/simulasi.php">SIMULASI</a></li>
			<li><a href="http://www.winkomputer.com/konfirmasi.php">KONFIRMASI TRANSFER</a></li>
			<li><a href="http://www.jne.co.id" target="_blank">TARIF JNE</a></li>
			<li><a href="#">SITEMAP</a></li>
		</ul></div>
		</div>
	</div>
	<div id="isi">
		<div id="isi1">
		<div id="error"></div>
		 <div class="title3"><h3>Konfirmasi Pembayaran</h3></div>
		 <div class="isi"> 
		 <form method="POST" name="contact_form" action="/konfirmasi.php">
		 <table>
		 <tr>
			<td width="25%" valign="top">Nama</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><input name="nama" value="" type="text" id="input-text"></td>
		 </tr><tr>
			<td width="25%" valign="top">Alamat</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><textarea name="alamat" rows="5" cols="35" id="input-textarea"></textarea></td>
		 </tr><tr>
			<td width="25%" valign="top">No Telp / Mobile HP</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><input name="telpon" value="" type="text" id="input-text"></td>
		 </tr><tr>
			<td width="25%" valign="top">Nominal Transfer (Rp.)</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><input name="nominal" value="" type="text" id="input-text"></td>
		 </tr><tr>
			<td width="25%" valign="top">Rekening Tujuan</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><select name="rekening">
			<option value="0" >----- Pilih Salah Satu -----</option>
			<option value="BCA" >BCA</option>
			<option value="MANDIRI"  >MANDIRI</option>
			</select></td>
		 </tr><tr>
			<td width="25%" valign="top">Tanggal Transfer</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><input name="tgl-transfer" value="" type="text" id="input-text"><br><em>format tanggal dd-mm-yyyy contoh : 01-01-2012, jika anda</em></td>
		 </tr><tr>
			<td width="25%" valign="top">Barang Yang Dipesan</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><textarea name="barang" rows="8" cols="35" id="input-textarea"></textarea></td>
		 </tr><tr>
			<td width="25%" valign="top">Paket JNE</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><select name="JNE">
			<option value="0" >-- Pilih Salah Satu --</option>
			<option value="JNE YES" >JNE YES</option>
			<option value="JNE OKE"  >JNE OKE</option>
			<option value="JNE REGULER" >JNE REGULER</option>
			<option value="JNE SPECIAL"  >JNE SPECIAL</option>
			</select></td>
		 </tr><tr>
			<td width="25%" valign="top">Biaya Kirim</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top"><input name="biaya-kirim" value="" type="text"></td>
		 </tr><tr>
			<td width="25%" valign="top">Kode Capcay</td>
			<td width="5%" valign="top">:</td>
			<td width="70%" valign="top">
			<div class="g-recaptcha" data-sitekey="6LeyjykTAAAAAOTdn4T-lrlxtB6f4GS2R2Z6GWO9"></div>
			</td>
		 </tr><tr>
			<td width="25%" valign="top">&nbsp;</td>
			<td width="5%" valign="top">&nbsp;</td>
			<td width="70%" valign="top"><input name="submit" value="Submit" type="submit" id="Submit"></td>
		 </tr>
		 </table>
		 </form>
		 </div>
		</div>
	</div>
</div> <!-- end of wrapping -->
		<div id="footer">
			<br><br>
			<big><big>&copy; <b>WIN COMPUTER - Toko Komputer Online Murah Surabaya</b></big></big><br>
			ITC Mega Grosir Lantai 2 Blok K3A no 3<br>Jl. Gembong No 20 - 30<br>Surabaya, Jawa Timur, Indonesia<br>CALL: 031-37301771 | WA: 085731000839 | EMAIL: win_komputer@yahoo.com<br>
			powered by <i><a href='http://www.marzuqnx.com'>Jizzo CMS 1.0</a></i>
			<h3><a href="#top">Top</a></h3>
		</div>
	</div>
	<br><br>
</body>
</html>